using UnityEngine;
using UnityEngine.SceneManagement;

public class SahneYukleyici : MonoBehaviour
{
    public void SahneAc(string sahneAdi)
    {
        Debug.Log(sahneAdi + " sahnesini a�mak i�in t�kland�!");

        SceneManager.LoadScene(sahneAdi);
    }
}