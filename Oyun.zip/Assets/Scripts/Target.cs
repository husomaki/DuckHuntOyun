using UnityEngine;

public class Target : MonoBehaviour
{
    public int scoreValue = 10;

    public void Hit()
    {
        if (GameManager.instance != null)
        {
            GameManager.instance.AddScore(scoreValue);
            Debug.Log("Puan eklendi: " + scoreValue);
        }
        else
        {
            Debug.LogWarning("GameManager.instance = null!");
        }

        Destroy(gameObject);
    }
}
