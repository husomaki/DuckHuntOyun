using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInput : MonoBehaviour
{
    private Camera cam;

    void Start()
    {
        cam = Camera.main;
    }

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = cam.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.CompareTag("Target"))
            {
                Debug.Log("HEDEF VURULDU: " + hit.collider.name);
                Target t = hit.collider.GetComponent<Target>();
                if (t != null) t.Hit();
            }
            else
            {
                Debug.Log("ISKA");
                if (GameManager.instance != null)
                    GameManager.instance.Miss();
            }
        }
    }
}
