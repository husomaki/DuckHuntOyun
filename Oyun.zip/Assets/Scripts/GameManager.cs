﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [Header("UI")]
    public Button quitButton;      
    public TMP_Text scoreText;
    public TMP_Text timerText;
    public TMP_Text bestScoreText;
    public GameObject gameOverPanel;
    public Button restartButton; 

    [Header("Gameplay")]
    public GameObject targetPrefab;
    public float spawnInterval = 1f;
    public int maxTargets = 5;
    public float spawnRangeX = 8f;
    public float spawnRangeY = 4f;
    public float gameDuration = 60f;

    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip hitSound;
    public AudioClip missSound;

    private int score = 0;
    private int bestScore = 0;
    private float timeRemaining;
    private bool isGameOver = false;

    void Awake()
    {
        instance = this;
        if (audioSource == null)
            audioSource = GetComponent<AudioSource>();
    }

    void Start()
    {
        bestScore = PlayerPrefs.GetInt("BestScore", 0);
        timeRemaining = gameDuration;
        UpdateScoreText();
        UpdateTimerText();
        UpdateBestScoreText();

        if (gameOverPanel != null)
            gameOverPanel.SetActive(false);

        if (restartButton != null)
            restartButton.onClick.AddListener(RestartGame);

        if (quitButton != null)
            quitButton.onClick.AddListener(QuitGame); 

        SpawnTarget();
    }

    void Update()
    {
        if (isGameOver) return;

        timeRemaining -= Time.deltaTime;
        if (timeRemaining <= 0)
        {
            EndGame();
        }

        UpdateTimerText();
    }

    

    void SpawnTarget()
    {

        GameObject existingTarget = GameObject.FindGameObjectWithTag("Target");
        if (existingTarget != null)
        {
            Destroy(existingTarget);
        }

        if (targetPrefab == null) return;
        float x = Random.Range(-spawnRangeX, spawnRangeX);
        float y = Random.Range(-spawnRangeY, spawnRangeY);
        Vector3 pos = new Vector3(x, y, 0f);
        Instantiate(targetPrefab, pos, Quaternion.identity);
    }

    public void AddScore(int amount)
    {
        if (isGameOver) return;

        score += amount;
        UpdateScoreText();
        PlaySound(hitSound);

        SpawnTarget();
    }

    public void Miss()
    {
        if (isGameOver) return;
        PlaySound(missSound);
    }

    void UpdateScoreText()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + score;
    }

    void UpdateBestScoreText()
    {
        if (bestScoreText != null)
            bestScoreText.text = "Best: " + bestScore;
    }

    void UpdateTimerText()
    {
        if (timerText != null)
            timerText.text = "Time: " + Mathf.CeilToInt(timeRemaining);
    }

    void EndGame()
    {
        isGameOver = true;

        if (score > bestScore)
        {
            bestScore = score;
            PlayerPrefs.SetInt("BestScore", bestScore);
            PlayerPrefs.Save();
        }

        UpdateBestScoreText();

        if (gameOverPanel != null)
            gameOverPanel.SetActive(true); 
    }

    void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip);
    }
    void QuitGame()
    {
        Debug.Log("QUIT BUTONUNA BASILDI!");
        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }
    public void StopButton()
    {

    }
}
